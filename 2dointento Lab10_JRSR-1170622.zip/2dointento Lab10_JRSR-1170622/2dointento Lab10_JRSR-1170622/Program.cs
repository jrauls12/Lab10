﻿using System;
class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ingresa el nombre de usuario");
        string ingresarusuario = Console.ReadLine();
        Console.WriteLine("Ingresa la contraseña del usuario");
        string ingresarcontraseña = Console.ReadLine();
        string credenciales = Login1(ingresarusuario);
        string credenciales1 = Login2(ingresarcontraseña);
        Console.WriteLine(credenciales + credenciales1);


    }

    public static string Login1(string usuario)
    {

        if (usuario == "usuario1")
        {
            Console.Write("usuaro:Válido      ");
        }

        else
        {
            Console.WriteLine("Vuelva a intentarlo.");
            while (usuario != "usuario1")
            {

                if (usuario == "usuario1")
                {
                    Console.Write("Válido");
                }
            }

        }
        return "";
    }
    public static string Login2(string contraseña)
    {
        if (contraseña == "asdasd")
        {
            Console.Write("Contraseña;Válida");
        }
        else
        {
            Console.WriteLine("Vuelva a intentarlo.");
            while (contraseña != "asdasd")
            {

                if (contraseña == "asdasd")
                {
                    Console.Write("Válido");
                }
            }

        }
        return "";
    }
}